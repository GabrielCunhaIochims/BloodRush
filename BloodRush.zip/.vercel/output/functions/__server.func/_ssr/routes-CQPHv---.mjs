import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CQPHv---.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var INITIAL = {
	hp: 100,
	maxHp: 100,
	kills: 0,
	wave: 1,
	score: 0,
	rank: "D",
	rankColor: "#a1a1aa",
	mult: 1,
	style: 0,
	best: 0,
	dashReady: true,
	phase: "menu",
	waveBanner: "",
	highScore: 0,
	looking: false,
	hitFlash: 0
};
function BloodRush() {
	const canvasRef = (0, import_react.useRef)(null);
	const gameRef = (0, import_react.useRef)(null);
	const [hud, setHud] = (0, import_react.useState)(INITIAL);
	const hudRef = (0, import_react.useRef)(hud);
	hudRef.current = hud;
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		let dead = false;
		let game = null;
		import("./engine-Bpi64lvc.mjs").then(({ createGame }) => {
			if (dead || !canvas) return;
			game = createGame(canvas, (next) => {
				const prev = hudRef.current;
				if (prev.phase !== next.phase || Math.ceil(prev.hp) !== Math.ceil(next.hp) || prev.kills !== next.kills || prev.wave !== next.wave || prev.score !== next.score || prev.rank !== next.rank || prev.dashReady !== next.dashReady || prev.waveBanner !== next.waveBanner || prev.looking !== next.looking || Math.floor(prev.mult * 10) !== Math.floor(next.mult * 10) || prev.hitFlash > .2 !== next.hitFlash > .2) setHud(next);
			});
			gameRef.current = game;
		});
		return () => {
			dead = true;
			game?.destroy();
			gameRef.current = null;
		};
	}, []);
	const hpPct = Math.max(0, Math.min(100, hud.hp / hud.maxHp * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "block h-full w-full touch-none",
				style: { touchAction: "none" }
			}),
			hud.phase === "playing" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-0 p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 rounded-lg border border-border bg-surface/80 px-3 py-2.5 backdrop-blur-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-1.5 h-2 w-44 overflow-hidden rounded-full bg-elevated sm:w-56",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-accent",
									style: { width: `${hpPct}%` }
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "grid grid-cols-2 gap-x-5 gap-y-0.5 font-mono text-xs tabular-nums text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["HP ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-fg",
										children: Math.max(0, Math.ceil(hud.hp))
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["WAVE ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-fg",
										children: hud.wave
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["KILLS ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-fg",
										children: hud.kills
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["SCORE ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-fg",
										children: hud.score
									})] })
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-display text-5xl leading-none tracking-wide sm:text-6xl",
									style: { color: hud.rankColor },
									children: hud.rank
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-mono text-xs tabular-nums text-muted",
									children: [
										"x",
										hud.mult.toFixed(1),
										" · ",
										Math.floor(hud.style)
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `mt-2 inline-block rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ${hud.dashReady ? "border-fg/30 text-fg" : "border-border text-subtle"}`,
									children: hud.dashReady ? "DASH" : "…"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `absolute left-1/2 top-1/2 h-4 w-px -translate-x-1/2 -translate-y-1/2 ${hud.hitFlash > .15 ? "bg-accent" : "bg-fg/80"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `absolute left-1/2 top-1/2 h-px w-4 -translate-x-1/2 -translate-y-1/2 ${hud.hitFlash > .15 ? "bg-accent" : "bg-fg/80"}` })]
					}),
					hud.waveBanner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute left-1/2 top-[38%] -translate-x-1/2 font-display text-6xl tracking-widest text-accent sm:text-7xl",
						children: hud.waveBanner
					}) : null,
					!hud.looking && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "absolute bottom-16 left-1/2 -translate-x-1/2 font-mono text-[11px] uppercase tracking-widest text-muted",
						children: "Clique para mirar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "absolute bottom-4 left-4 hidden font-mono text-[10px] uppercase tracking-widest text-subtle sm:block",
						children: "WASD mover · mouse mirar · clique atirar · shift dash"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-x-0 bottom-6 flex justify-between px-6 sm:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 w-24 rounded-full border border-border bg-surface/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 w-16 rounded-full border border-border bg-surface/40" })]
			}),
			hud.phase === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 flex flex-col items-center justify-center bg-bg/80 px-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 font-mono text-[11px] uppercase tracking-[0.35em] text-accent",
						children: "Arena 3D"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-7xl leading-none tracking-wide text-fg sm:text-8xl",
						children: "BLOOD RUSH"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md font-sans text-sm leading-relaxed text-muted",
						children: "Primeira pessoa. Shotgun. Dash atravessa demônios. Suba o rank de estilo."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-6 space-y-1 font-mono text-[11px] uppercase tracking-wider text-subtle",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "WASD — mover" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Mouse — olhar e atirar" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Shift — dash" })
						]
					}),
					hud.highScore > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 font-mono text-xs tabular-nums text-muted",
						children: ["Recorde ", hud.highScore]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-8 min-h-11 rounded-md bg-fg px-8 py-3 font-sans text-sm font-medium text-bg transition-transform duration-150 hover:opacity-90 active:scale-[0.98]",
						onClick: () => gameRef.current?.start(),
						children: "Começar"
					})
				]
			}),
			hud.phase === "dead" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 flex flex-col items-center justify-center bg-bg/88 px-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[11px] uppercase tracking-[0.35em] text-accent",
						children: "Caído"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-6xl tracking-wide text-fg",
						children: "VOCÊ MORREU"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 font-mono text-lg tabular-nums text-fg",
						children: hud.score
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-mono text-xs text-muted",
						children: [
							hud.kills,
							" kills · wave ",
							hud.wave,
							" · rank ",
							hud.rank
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-mono text-xs text-subtle",
						children: ["Recorde ", hud.highScore]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-8 min-h-11 rounded-md bg-fg px-8 py-3 font-sans text-sm font-medium text-bg transition-transform duration-150 hover:opacity-90 active:scale-[0.98]",
						onClick: () => gameRef.current?.start(),
						children: "Tentar de novo"
					})
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BloodRush, {});
}
//#endregion
export { Home as component };
