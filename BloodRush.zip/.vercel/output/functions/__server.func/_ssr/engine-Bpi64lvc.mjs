import { C as Vector2, S as SphereGeometry, _ as PlaneGeometry, a as ConeGeometry, b as SRGBColorSpace, c as FogExp2, d as HemisphereLight, f as Mesh, g as PerspectiveCamera, h as Object3D, i as Color, l as GridHelper, m as MeshStandardMaterial, n as BoxGeometry, o as CylinderGeometry, p as MeshBasicMaterial, r as CapsuleGeometry, s as DirectionalLight, t as WebGLRenderer, u as Group, v as PointLight, w as Vector3, x as Scene, y as Raycaster } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-Bpi64lvc.js
function createAudio() {
	const AC = window.AudioContext || window.webkitAudioContext;
	if (!AC) return null;
	const ctx = new AC({ latencyHint: "interactive" });
	const master = ctx.createGain();
	master.gain.value = .55;
	const sfx = ctx.createGain();
	sfx.gain.value = 1;
	sfx.connect(master);
	master.connect(ctx.destination);
	return {
		ctx,
		master,
		sfx
	};
}
function unlockAudio(bus) {
	if (!bus) return;
	if (bus.ctx.state === "suspended") bus.ctx.resume();
}
function beep(bus, freq, dur, type, gain = .12, slide = 0) {
	const t = bus.ctx.currentTime;
	const o = bus.ctx.createOscillator();
	const g = bus.ctx.createGain();
	o.type = type;
	o.frequency.setValueAtTime(freq, t);
	if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
	g.gain.setValueAtTime(1e-4, t);
	g.gain.exponentialRampToValueAtTime(gain, t + .008);
	g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
	o.connect(g);
	g.connect(bus.sfx);
	o.start(t);
	o.stop(t + dur + .02);
}
var sfx = {
	shoot(bus) {
		if (!bus) return;
		beep(bus, 180 + Math.random() * 40, .08, "square", .07, -80);
	},
	dash(bus) {
		if (!bus) return;
		beep(bus, 420, .12, "sawtooth", .08, -280);
	},
	hit(bus) {
		if (!bus) return;
		beep(bus, 90 + Math.random() * 30, .09, "triangle", .1, -40);
	},
	kill(bus) {
		if (!bus) return;
		beep(bus, 140, .18, "sawtooth", .11, -90);
		beep(bus, 280, .12, "square", .05, 120);
	},
	hurt(bus) {
		if (!bus) return;
		beep(bus, 70, .22, "sawtooth", .14, -30);
	},
	wave(bus) {
		if (!bus) return;
		beep(bus, 220, .25, "triangle", .08, 180);
	}
};
var RANKS = [
	{
		name: "D",
		min: 0,
		color: "#a1a1aa"
	},
	{
		name: "C",
		min: 50,
		color: "#67e8f9"
	},
	{
		name: "B",
		min: 150,
		color: "#86efac"
	},
	{
		name: "A",
		min: 350,
		color: "#fdba74"
	},
	{
		name: "S",
		min: 600,
		color: "#f87171"
	},
	{
		name: "SS",
		min: 1e3,
		color: "#fb7185"
	},
	{
		name: "SSS",
		min: 1600,
		color: "#fda4af"
	},
	{
		name: "GODLIKE",
		min: 2500,
		color: "#fafafa"
	}
];
var ARENA = 18;
var PLAYER_R = .38;
var EYE = 1.55;
var HS_KEY = "blood-rush-highscore";
function rand(a, b) {
	return a + Math.random() * (b - a);
}
function clamp(v, lo, hi) {
	return Math.max(lo, Math.min(hi, v));
}
function createGame(canvas, onHud) {
	const renderer = new WebGLRenderer({
		canvas,
		antialias: true,
		alpha: false
	});
	renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
	renderer.setSize(canvas.clientWidth || 1, canvas.clientHeight || 1, false);
	renderer.shadowMap.enabled = true;
	renderer.autoClear = false;
	renderer.outputColorSpace = SRGBColorSpace;
	renderer.toneMapping = 4;
	renderer.toneMappingExposure = 1.05;
	const scene = new Scene();
	scene.background = new Color(656902);
	scene.fog = new FogExp2(1181704, .035);
	const overlay = new Scene();
	const overlayCam = new PerspectiveCamera(55, 1, .05, 10);
	overlayCam.position.set(0, 0, 0);
	const yawObj = new Object3D();
	yawObj.position.set(0, 0, 0);
	scene.add(yawObj);
	const camera = new PerspectiveCamera(80, 1, .08, 120);
	camera.position.set(0, EYE, 0);
	yawObj.add(camera);
	const gun = makeShotgun();
	overlay.add(gun);
	buildArena(scene);
	const keys = /* @__PURE__ */ new Set();
	let keyOverride = null;
	let yaw = 0;
	let pitch = 0;
	let px = 0;
	let pz = 0;
	let vx = 0;
	let vz = 0;
	let looking = false;
	let pointerDown = false;
	let fireHeld = false;
	let lookFallback = false;
	const stick = {
		active: false,
		id: -1,
		ox: 0,
		oy: 0,
		dx: 0,
		dy: 0
	};
	const lookTouch = {
		active: false,
		id: -1,
		lx: 0,
		ly: 0
	};
	const player = {
		hp: 100,
		maxHp: 100,
		speed: 8.4,
		dashSpeed: 22,
		dashing: false,
		dashTime: 0,
		fireCd: 0,
		fireRate: .42
	};
	const enemies = [];
	const shots = [];
	const sparks = [];
	const colliders = [
		{
			x: 6,
			z: 6,
			r: 1.15
		},
		{
			x: -6,
			z: 6,
			r: 1.15
		},
		{
			x: 6,
			z: -6,
			r: 1.15
		},
		{
			x: -6,
			z: -6,
			r: 1.15
		},
		{
			x: 0,
			z: 9,
			r: .85
		},
		{
			x: 0,
			z: -9,
			r: .85
		}
	];
	const raycaster = new Raycaster();
	new Vector2(0, 0);
	const fwd = new Vector3();
	const right = new Vector3();
	new Vector3();
	let phase = "menu";
	let score = 0;
	let kills = 0;
	let wave = 1;
	let stylePoints = 0;
	let styleDecay = 0;
	let styleMultiplier = 1;
	let currentRank = RANKS[0];
	let dashCooldown = 0;
	let invuln = 0;
	let shake = 0;
	let recoil = 0;
	let spawnQueue = 0;
	let spawnTimer = 0;
	let waveBanner = "";
	let waveBannerT = 0;
	let hitFlash = 0;
	let bob = 0;
	let last = 0;
	let acc = 0;
	let raf = 0;
	let bus = null;
	let highScore = Number(localStorage.getItem(HS_KEY) || "0") || 0;
	let running = true;
	function hud() {
		return {
			hp: Math.max(0, player.hp),
			maxHp: player.maxHp,
			kills,
			wave,
			score,
			rank: currentRank.name,
			rankColor: currentRank.color,
			mult: styleMultiplier,
			style: stylePoints,
			best: highScore,
			dashReady: dashCooldown <= 0,
			phase,
			waveBanner,
			highScore,
			looking,
			hitFlash
		};
	}
	function emitHud() {
		onHud(hud());
	}
	function resize() {
		const w = Math.max(1, canvas.clientWidth);
		const h = Math.max(1, canvas.clientHeight);
		renderer.setSize(w, h, false);
		camera.aspect = w / h;
		camera.updateProjectionMatrix();
		overlayCam.aspect = w / h;
		overlayCam.updateProjectionMatrix();
	}
	function updateRank() {
		let r = RANKS[0];
		for (const rank of RANKS) if (stylePoints >= rank.min) r = rank;
		currentRank = r;
	}
	function addStyle(pts) {
		stylePoints += pts * styleMultiplier;
		styleDecay = 3.4;
		styleMultiplier = Math.min(3, styleMultiplier + .05);
		updateRank();
	}
	function spawnSpark(x, y, z, color, n = 8, spd = 4) {
		for (let i = 0; i < n; i++) {
			const a = rand(0, Math.PI * 2);
			const el = rand(-.4, 1);
			const s = rand(spd * .3, spd);
			let slot = sparks.find((p) => !p.active);
			if (!slot) {
				const mesh = new Mesh(new SphereGeometry(.06, 6, 6), new MeshBasicMaterial({ color }));
				slot = {
					mesh,
					vx: 0,
					vy: 0,
					vz: 0,
					life: 0,
					active: false
				};
				sparks.push(slot);
				scene.add(mesh);
			}
			slot.active = true;
			slot.mesh.visible = true;
			slot.mesh.material.color.setHex(color);
			slot.mesh.position.set(x, y, z);
			slot.vx = Math.cos(a) * s;
			slot.vz = Math.sin(a) * s;
			slot.vy = el * s;
			slot.life = rand(.2, .55);
		}
	}
	function spawnEnemy(kind, x, z) {
		let e = enemies.find((o) => !o.active);
		if (!e) {
			e = makeEnemy(kind);
			enemies.push(e);
			scene.add(e.mesh);
		} else restyleEnemy(e, kind);
		e.active = true;
		e.mesh.visible = true;
		e.hp = e.maxHp;
		e.fireCd = rand(.2, 1);
		e.angle = rand(0, Math.PI * 2);
		e.hitFlash = 0;
		e.vx = 0;
		e.vz = 0;
		e.mesh.position.set(x, e.kind === "wraith" ? 1.4 : 0, z);
	}
	function spawnWave(n) {
		spawnQueue = 4 + Math.floor(n * 1.4);
		spawnTimer = .2;
	}
	function killEnemy(e) {
		e.active = false;
		e.mesh.visible = false;
		kills += 1;
		score += Math.floor(e.score * styleMultiplier);
		addStyle(e.style);
		spawnSpark(e.mesh.position.x, e.mesh.position.y + 1, e.mesh.position.z, 10033947, 18, 7);
		player.hp = Math.min(player.maxHp, player.hp + 6);
		sfx.kill(bus);
		shake = Math.max(shake, .12);
	}
	function fire() {
		if (phase !== "playing" || player.fireCd > 0) return;
		player.fireCd = player.fireRate;
		recoil = .085;
		shake = Math.max(shake, .06);
		sfx.shoot(bus);
		camera.getWorldDirection(fwd);
		const origin = new Vector3();
		camera.getWorldPosition(origin);
		const pellets = 7;
		for (let i = 0; i < pellets; i++) {
			const dir = fwd.clone();
			dir.x += rand(-.08, .08);
			dir.y += rand(-.05, .05);
			dir.z += rand(-.08, .08);
			dir.normalize();
			raycaster.set(origin, dir);
			const bodies = enemies.filter((e) => e.active).map((e) => e.body);
			const hits = raycaster.intersectObjects(bodies, false);
			if (hits.length && hits[0].distance < 28) {
				const hit = hits[0];
				const e = enemies.find((en) => en.body === hit.object);
				spawnSpark(hit.point.x, hit.point.y, hit.point.z, 14427686, 4, 3);
				if (e) {
					e.hp -= 14;
					e.hitFlash = .1;
					hitFlash = 1;
					sfx.hit(bus);
					if (e.hp <= 0) killEnemy(e);
				}
			} else {
				const end = origin.clone().addScaledVector(dir, 18);
				spawnSpark(end.x, end.y, end.z, 16498468, 1, .4);
			}
		}
	}
	function enemyShoot(e) {
		const origin = e.mesh.position.clone();
		origin.y += 1.1;
		const dir = new Vector3(px, EYE, pz).sub(origin).normalize();
		let slot = shots.find((s) => !s.active);
		if (!slot) {
			const mesh = new Mesh(new SphereGeometry(.12, 8, 8), new MeshBasicMaterial({ color: 16478597 }));
			slot = {
				mesh,
				vx: 0,
				vy: 0,
				vz: 0,
				life: 0,
				damage: 0,
				fromPlayer: false,
				active: false
			};
			shots.push(slot);
			scene.add(mesh);
		}
		slot.active = true;
		slot.mesh.visible = true;
		slot.mesh.position.copy(origin);
		const spd = 11;
		slot.vx = dir.x * spd;
		slot.vy = dir.y * spd;
		slot.vz = dir.z * spd;
		slot.life = 2.4;
		slot.damage = e.damage;
		slot.fromPlayer = false;
	}
	function collideXZ(x, z, r) {
		const lim = 17.3 - r;
		x = clamp(x, -lim, lim);
		z = clamp(z, -lim, lim);
		for (const c of colliders) {
			const dx = x - c.x;
			const dz = z - c.z;
			const min = r + c.r;
			const d = Math.hypot(dx, dz);
			if (d < min && d > 1e-4) {
				const k = min / d;
				x = c.x + dx * k;
				z = c.z + dz * k;
			}
		}
		return {
			x,
			z
		};
	}
	function reset() {
		px = 0;
		pz = 0;
		vx = 0;
		vz = 0;
		yaw = 0;
		pitch = 0;
		player.hp = player.maxHp;
		player.dashing = false;
		player.dashTime = 0;
		player.fireCd = 0;
		enemies.forEach((e) => {
			e.active = false;
			e.mesh.visible = false;
		});
		shots.forEach((s) => {
			s.active = false;
			s.mesh.visible = false;
		});
		sparks.forEach((s) => {
			s.active = false;
			s.mesh.visible = false;
		});
		score = 0;
		kills = 0;
		wave = 1;
		stylePoints = 0;
		styleMultiplier = 1;
		styleDecay = 0;
		currentRank = RANKS[0];
		dashCooldown = 0;
		invuln = 0;
		shake = 0;
		recoil = 0;
		spawnWave(1);
		waveBanner = "WAVE 1";
		waveBannerT = 1.6;
		phase = "playing";
		sfx.wave(bus);
		emitHud();
		tryLock();
	}
	function die() {
		phase = "dead";
		highScore = Math.max(highScore, score);
		localStorage.setItem(HS_KEY, String(highScore));
		if (document.pointerLockElement) document.exitPointerLock();
		looking = false;
		emitHud();
	}
	function held() {
		if (keyOverride) return new Set(keyOverride);
		return keys;
	}
	function tryLock() {
		const p = canvas.requestPointerLock.call(canvas, { unadjustedMovement: true });
		if (p && typeof p.catch === "function") p.catch(() => {
			try {
				canvas.requestPointerLock();
			} catch {
				lookFallback = true;
			}
		});
	}
	function step(dt) {
		if (phase !== "playing") {
			yawObj.position.set(px, 0, pz);
			yawObj.rotation.y = yaw;
			camera.rotation.x = pitch;
			return;
		}
		styleDecay -= dt;
		if (styleDecay <= 0) {
			stylePoints = Math.max(0, stylePoints - 42 * dt);
			styleMultiplier = Math.max(1, styleMultiplier - .16 * dt);
			updateRank();
		}
		dashCooldown = Math.max(0, dashCooldown - dt);
		invuln = Math.max(0, invuln - dt);
		player.fireCd = Math.max(0, player.fireCd - dt);
		hitFlash = Math.max(0, hitFlash - dt * 3);
		recoil = Math.max(0, recoil - dt * .45);
		shake = Math.max(0, shake - dt * 1.6);
		fwd.set(-Math.sin(yaw), 0, -Math.cos(yaw));
		right.set(Math.cos(yaw), 0, -Math.sin(yaw));
		const k = held();
		let mx = 0;
		let mz = 0;
		if (k.has("KeyW") || k.has("ArrowUp")) {
			mx += fwd.x;
			mz += fwd.z;
		}
		if (k.has("KeyS") || k.has("ArrowDown")) {
			mx -= fwd.x;
			mz -= fwd.z;
		}
		if (k.has("KeyD") || k.has("ArrowRight")) {
			mx += right.x;
			mz += right.z;
		}
		if (k.has("KeyA") || k.has("ArrowLeft")) {
			mx -= right.x;
			mz -= right.z;
		}
		if (stick.active) {
			mx += right.x * stick.dx + fwd.x * -stick.dy;
			mz += right.z * stick.dx + fwd.z * -stick.dy;
		}
		const mlen = Math.hypot(mx, mz);
		if (mlen > .12) {
			mx /= mlen;
			mz /= mlen;
		} else {
			mx = 0;
			mz = 0;
		}
		if ((k.has("ShiftLeft") || k.has("ShiftRight") || k.has("KeyE")) && dashCooldown <= 0 && !player.dashing) {
			player.dashing = true;
			player.dashTime = .16;
			dashCooldown = .72;
			invuln = .18;
			const dx = mx || fwd.x;
			const dz = mz || fwd.z;
			const len = Math.hypot(dx, dz) || 1;
			vx = dx / len * player.dashSpeed;
			vz = dz / len * player.dashSpeed;
			addStyle(8);
			sfx.dash(bus);
			spawnSpark(px, .4, pz, 15000807, 10, 5);
		}
		if (player.dashing) {
			player.dashTime -= dt;
			if (player.dashTime <= 0) {
				player.dashing = false;
				vx *= .3;
				vz *= .3;
			}
		} else {
			vx += (mx * player.speed - vx) * 12 * dt;
			vz += (mz * player.speed - vz) * 12 * dt;
		}
		const c = collideXZ(px + vx * dt, pz + vz * dt, PLAYER_R);
		px = c.x;
		pz = c.z;
		if (fireHeld) fire();
		for (const e of enemies) {
			if (!e.active) continue;
			e.hitFlash = Math.max(0, e.hitFlash - dt);
			e.body.material.emissive.setHex(e.hitFlash > 0 ? 16777215 : 2228224);
			const dx = px - e.mesh.position.x;
			const dz = pz - e.mesh.position.z;
			const dist = Math.hypot(dx, dz) || 1;
			const ax = dx / dist;
			const az = dz / dist;
			if (e.behavior === "chase") {
				e.vx = ax * e.speed;
				e.vz = az * e.speed;
			} else if (e.behavior === "circle") {
				e.angle += 1.8 * dt;
				const orbit = 5.5;
				const tx = px + Math.cos(e.angle) * orbit;
				const tz = pz + Math.sin(e.angle) * orbit;
				e.vx = (tx - e.mesh.position.x) * 2.2;
				e.vz = (tz - e.mesh.position.z) * 2.2;
			} else {
				if (dist < 7) {
					e.vx = -ax * e.speed * .8;
					e.vz = -az * e.speed * .8;
				} else if (dist > 12) {
					e.vx = ax * e.speed;
					e.vz = az * e.speed;
				} else {
					e.vx *= .9;
					e.vz *= .9;
				}
				e.fireCd -= dt;
				if (e.fireCd <= 0) {
					enemyShoot(e);
					e.fireCd = e.fireRate + rand(-.15, .2);
				}
			}
			for (const o of enemies) {
				if (!o.active || o === e) continue;
				const ox = e.mesh.position.x - o.mesh.position.x;
				const oz = e.mesh.position.z - o.mesh.position.z;
				const dd = Math.hypot(ox, oz);
				const min = e.r + o.r + .2;
				if (dd > 0 && dd < min) {
					e.vx += ox / dd * 4;
					e.vz += oz / dd * 4;
				}
			}
			const ep = collideXZ(e.mesh.position.x + e.vx * dt, e.mesh.position.z + e.vz * dt, e.r);
			e.mesh.position.x = ep.x;
			e.mesh.position.z = ep.z;
			e.mesh.position.y = e.kind === "wraith" ? 1.35 + Math.sin(performance.now() * .004 + e.angle) * .2 : 0;
			e.mesh.lookAt(px, e.mesh.position.y, pz);
			if (Math.hypot(px - e.mesh.position.x, pz - e.mesh.position.z) < PLAYER_R + e.r) {
				if (player.dashing) {
					killEnemy(e);
					addStyle(28);
				} else if (invuln <= 0) {
					player.hp -= e.damage * dt * 1.8;
					shake = .14;
					if (player.hp <= 0) die();
				}
			}
		}
		for (const s of shots) {
			if (!s.active) continue;
			s.mesh.position.x += s.vx * dt;
			s.mesh.position.y += s.vy * dt;
			s.mesh.position.z += s.vz * dt;
			s.life -= dt;
			if (s.life <= 0 || Math.abs(s.mesh.position.x) > ARENA || Math.abs(s.mesh.position.z) > ARENA) {
				s.active = false;
				s.mesh.visible = false;
				continue;
			}
			const d = Math.hypot(s.mesh.position.x - px, s.mesh.position.z - pz);
			const dy = s.mesh.position.y - EYE;
			if (invuln <= 0 && d < .55 && Math.abs(dy) < .8) {
				player.hp -= s.damage;
				invuln = .35;
				shake = .18;
				s.active = false;
				s.mesh.visible = false;
				sfx.hurt(bus);
				if (player.hp <= 0) die();
			}
		}
		for (const p of sparks) {
			if (!p.active) continue;
			p.mesh.position.x += p.vx * dt;
			p.mesh.position.y += p.vy * dt;
			p.mesh.position.z += p.vz * dt;
			p.vy -= 12 * dt;
			p.life -= dt;
			if (p.life <= 0 || p.mesh.position.y < .05) {
				p.active = false;
				p.mesh.visible = false;
			}
		}
		if (spawnQueue > 0) {
			spawnTimer -= dt;
			if (spawnTimer <= 0) {
				const edge = Math.floor(rand(0, 4));
				let x = 0;
				let z = 0;
				if (edge === 0) {
					x = rand(-16, 16);
					z = -16.5;
				} else if (edge === 1) {
					x = 16.5;
					z = rand(-16, 16);
				} else if (edge === 2) {
					x = rand(-16, 16);
					z = 16.5;
				} else {
					x = -16.5;
					z = rand(-16, 16);
				}
				const r = Math.random();
				let kind = "fiend";
				if (wave >= 8 && r < .16) kind = "brute";
				else if (wave >= 4 && r < .24) kind = "brute";
				else if (r < .34) kind = "gunner";
				else if (r < .55) kind = "wraith";
				spawnEnemy(kind, x, z);
				spawnQueue -= 1;
				spawnTimer = Math.max(.08, .28 - wave * .012);
			}
		} else if (enemies.every((e) => !e.active)) {
			wave += 1;
			score += wave * 50;
			addStyle(50);
			spawnWave(wave);
			waveBanner = `WAVE ${wave}`;
			waveBannerT = 1.5;
			sfx.wave(bus);
		}
		if (waveBannerT > 0) {
			waveBannerT -= dt;
			if (waveBannerT <= 0) waveBanner = "";
		}
		const spd = Math.hypot(vx, vz);
		if (spd > .4) bob += dt * spd * 1.8;
		yawObj.position.set(px, 0, pz);
		yawObj.rotation.y = yaw;
		camera.rotation.x = pitch + recoil;
		camera.position.y = EYE + Math.sin(bob) * .035;
		camera.position.x = (Math.random() - .5) * shake;
		camera.position.z = (Math.random() - .5) * shake;
		gun.position.set(.32, -.28 - recoil * .6, -.62);
		gun.rotation.x = recoil * 1.4;
		gun.rotation.y = .08;
	}
	function draw() {
		renderer.clear();
		renderer.render(scene, camera);
		renderer.clearDepth();
		renderer.render(overlay, overlayCam);
	}
	function loop(t) {
		if (!running) return;
		if (!last) last = t;
		const raw = Math.min((t - last) / 1e3, .08);
		last = t;
		acc += raw;
		const stepDt = 1 / 60;
		while (acc >= stepDt) {
			step(stepDt);
			acc -= stepDt;
		}
		draw();
		emitHud();
		raf = requestAnimationFrame(loop);
	}
	function onMouseMove(e) {
		if (phase !== "playing") return;
		const locked = document.pointerLockElement === canvas;
		looking = locked || lookFallback || pointerDown;
		if (!locked && !lookFallback && !pointerDown && !lookTouch.active) return;
		yaw -= e.movementX * .0022;
		pitch -= e.movementY * .0022;
		pitch = clamp(pitch, -1.4, 1.4);
	}
	function onPointerLockChange() {
		looking = document.pointerLockElement === canvas;
		emitHud();
	}
	function onKeyDown(e) {
		keys.add(e.code);
		if (e.code === "KeyR" && phase === "playing") reset();
		if ((e.code === "Space" || e.code === "Enter") && phase === "menu") start();
		if ([
			"Space",
			"ArrowUp",
			"ArrowDown",
			"ArrowLeft",
			"ArrowRight"
		].includes(e.code)) e.preventDefault();
	}
	function onKeyUp(e) {
		keys.delete(e.code);
	}
	function onBlur() {
		keys.clear();
	}
	function onPointerDown(e) {
		if (e.pointerType === "touch") {
			if (e.clientX < window.innerWidth * .42) {
				stick.active = true;
				stick.id = e.pointerId;
				stick.ox = e.clientX;
				stick.oy = e.clientY;
				stick.dx = 0;
				stick.dy = 0;
			} else {
				lookTouch.active = true;
				lookTouch.id = e.pointerId;
				lookTouch.lx = e.clientX;
				lookTouch.ly = e.clientY;
				fireHeld = true;
				looking = true;
			}
		} else {
			pointerDown = true;
			fireHeld = true;
			if (phase === "playing") tryLock();
		}
	}
	function onPointerMove(e) {
		if (stick.active && e.pointerId === stick.id) {
			const dx = (e.clientX - stick.ox) / 56;
			const dy = (e.clientY - stick.oy) / 56;
			const len = Math.hypot(dx, dy) || 1;
			stick.dx = dx / Math.max(1, len);
			stick.dy = dy / Math.max(1, len);
			return;
		}
		if (lookTouch.active && e.pointerId === lookTouch.id) {
			yaw -= (e.clientX - lookTouch.lx) * .005;
			pitch -= (e.clientY - lookTouch.ly) * .005;
			pitch = clamp(pitch, -1.4, 1.4);
			lookTouch.lx = e.clientX;
			lookTouch.ly = e.clientY;
		}
	}
	function onPointerUp(e) {
		if (stick.active && e.pointerId === stick.id) {
			stick.active = false;
			stick.dx = 0;
			stick.dy = 0;
		}
		if (lookTouch.active && e.pointerId === lookTouch.id) lookTouch.active = false;
		pointerDown = false;
		fireHeld = false;
	}
	function start() {
		if (!bus) bus = createAudio();
		unlockAudio(bus);
		reset();
	}
	window.addEventListener("keydown", onKeyDown);
	window.addEventListener("keyup", onKeyUp);
	window.addEventListener("blur", onBlur);
	window.addEventListener("mousemove", onMouseMove);
	document.addEventListener("pointerlockchange", onPointerLockChange);
	document.addEventListener("visibilitychange", () => {
		if (document.visibilityState === "visible") unlockAudio(bus);
	});
	canvas.addEventListener("pointerdown", onPointerDown);
	canvas.addEventListener("pointermove", onPointerMove);
	canvas.addEventListener("pointerup", onPointerUp);
	canvas.addEventListener("pointercancel", onPointerUp);
	window.addEventListener("resize", resize);
	resize();
	emitHud();
	raf = requestAnimationFrame(loop);
	window.__controlsTest = {
		getYaw: () => yaw,
		getSpeed: () => Math.hypot(vx, vz),
		getX: () => px,
		getZ: () => pz,
		setKeys: (codes) => {
			keyOverride = codes;
		},
		start,
		isPlaying: () => phase === "playing"
	};
	return {
		start,
		destroy() {
			running = false;
			cancelAnimationFrame(raf);
			window.removeEventListener("keydown", onKeyDown);
			window.removeEventListener("keyup", onKeyUp);
			window.removeEventListener("blur", onBlur);
			window.removeEventListener("mousemove", onMouseMove);
			window.removeEventListener("resize", resize);
			document.removeEventListener("pointerlockchange", onPointerLockChange);
			canvas.removeEventListener("pointerdown", onPointerDown);
			canvas.removeEventListener("pointermove", onPointerMove);
			canvas.removeEventListener("pointerup", onPointerUp);
			canvas.removeEventListener("pointercancel", onPointerUp);
			renderer.dispose();
			window.__controlsTest = void 0;
		}
	};
}
function makeShotgun() {
	const g = new Group();
	const metal = new MeshStandardMaterial({
		color: 2565930,
		metalness: .7,
		roughness: .35
	});
	const wood = new MeshStandardMaterial({
		color: 4139549,
		metalness: .1,
		roughness: .8
	});
	const red = new MeshStandardMaterial({
		color: 14753053,
		emissive: 8330525,
		metalness: .2,
		roughness: .4
	});
	const barrel = new Mesh(new CylinderGeometry(.035, .04, .7, 10), metal);
	barrel.rotation.x = Math.PI / 2;
	barrel.position.set(0, .02, -.15);
	const barrel2 = barrel.clone();
	barrel2.position.x = .07;
	const body = new Mesh(new BoxGeometry(.16, .1, .28), metal);
	body.position.set(.035, -.02, .18);
	const stock = new Mesh(new BoxGeometry(.08, .12, .22), wood);
	stock.position.set(.03, -.06, .38);
	const sight = new Mesh(new BoxGeometry(.02, .04, .02), red);
	sight.position.set(.035, .08, -.42);
	g.add(barrel, barrel2, body, stock, sight);
	g.traverse((obj) => {
		const m = obj;
		if (m.isMesh) {
			m.castShadow = false;
			m.layers.set(0);
		}
	});
	return g;
}
function makeEnemy(kind) {
	const spec = specFor(kind);
	const group = new Group();
	const mat = new MeshStandardMaterial({
		color: spec.color,
		emissive: 2228224,
		roughness: .55,
		metalness: .15
	});
	const body = new Mesh(new CapsuleGeometry(spec.r * .55, spec.h, 6, 10), mat);
	body.position.y = spec.h * .5 + spec.r * .55;
	body.castShadow = true;
	const hornGeo = new ConeGeometry(.08, .28, 6);
	const hornL = new Mesh(hornGeo, mat);
	const hornR = hornL.clone();
	hornL.position.set(-.16, spec.h + .35, .05);
	hornR.position.set(.16, spec.h + .35, .05);
	hornL.rotation.z = .35;
	hornR.rotation.z = -.35;
	const eye = new Mesh(new SphereGeometry(.08, 8, 8), new MeshBasicMaterial({ color: 16448250 }));
	eye.position.set(0, spec.h * .7, spec.r * .45);
	group.add(body, hornL, hornR, eye);
	return {
		kind,
		mesh: group,
		body,
		hp: spec.hp,
		maxHp: spec.hp,
		speed: spec.speed,
		r: spec.r,
		score: spec.score,
		style: spec.style,
		damage: spec.damage,
		behavior: spec.behavior,
		fireRate: spec.fireRate,
		fireCd: 0,
		angle: 0,
		hitFlash: 0,
		active: false,
		vx: 0,
		vz: 0
	};
}
function restyleEnemy(e, kind) {
	const spec = specFor(kind);
	e.kind = kind;
	e.hp = spec.hp;
	e.maxHp = spec.hp;
	e.speed = spec.speed;
	e.r = spec.r;
	e.score = spec.score;
	e.style = spec.style;
	e.damage = spec.damage;
	e.behavior = spec.behavior;
	e.fireRate = spec.fireRate;
	e.body.material.color.setHex(spec.color);
}
function specFor(kind) {
	if (kind === "brute") return {
		color: 8138002,
		hp: 160,
		speed: 2.1,
		r: .7,
		h: 1.6,
		score: 360,
		style: 42,
		damage: 24,
		behavior: "chase",
		fireRate: 0
	};
	if (kind === "gunner") return {
		color: 1920728,
		hp: 70,
		speed: 2.8,
		r: .45,
		h: 1.2,
		score: 180,
		style: 24,
		damage: 14,
		behavior: "shoot",
		fireRate: 1.2
	};
	if (kind === "wraith") return {
		color: 10424889,
		hp: 28,
		speed: 4.4,
		r: .35,
		h: .9,
		score: 130,
		style: 20,
		damage: 10,
		behavior: "circle",
		fireRate: 0
	};
	return {
		color: 12131356,
		hp: 40,
		speed: 3.5,
		r: .42,
		h: 1.05,
		score: 100,
		style: 14,
		damage: 12,
		behavior: "chase",
		fireRate: 0
	};
}
function buildArena(scene) {
	const floorMat = new MeshStandardMaterial({
		color: 1840148,
		roughness: .92,
		metalness: .05
	});
	const floor = new Mesh(new PlaneGeometry(36, 36), floorMat);
	floor.rotation.x = -Math.PI / 2;
	floor.receiveShadow = true;
	scene.add(floor);
	const grid = new GridHelper(36, 24, 4136221, 2757909);
	grid.position.y = .01;
	scene.add(grid);
	const wallMat = new MeshStandardMaterial({
		color: 2758680,
		roughness: .85
	});
	const wallH = 5;
	const thick = .6;
	const walls = [
		{
			x: 0,
			z: -18,
			w: 37,
			d: thick
		},
		{
			x: 0,
			z: ARENA,
			w: 37,
			d: thick
		},
		{
			x: -18,
			z: 0,
			w: thick,
			d: 37
		},
		{
			x: ARENA,
			z: 0,
			w: thick,
			d: 37
		}
	];
	for (const w of walls) {
		const m = new Mesh(new BoxGeometry(w.w, wallH, w.d), wallMat);
		m.position.set(w.x, wallH / 2, w.z);
		m.castShadow = true;
		m.receiveShadow = true;
		scene.add(m);
	}
	const colMat = new MeshStandardMaterial({
		color: 4136735,
		roughness: .7
	});
	for (const [x, z] of [
		[6, 6],
		[-6, 6],
		[6, -6],
		[-6, -6],
		[0, 9],
		[0, -9]
	]) {
		const col = new Mesh(new CylinderGeometry(.9, 1.05, 4.2, 10), colMat);
		col.position.set(x, 2.1, z);
		col.castShadow = true;
		scene.add(col);
	}
	const hemi = new HemisphereLight(16764868, 1706506, .55);
	scene.add(hemi);
	const dir = new DirectionalLight(16770262, 1.05);
	dir.position.set(8, 14, 6);
	dir.castShadow = true;
	dir.shadow.mapSize.set(1024, 1024);
	scene.add(dir);
	const red = new PointLight(14753053, 18, 28, 1.6);
	red.position.set(0, 3.2, 0);
	scene.add(red);
	const fill = new PointLight(8330525, 8, 22);
	fill.position.set(-8, 2.4, 8);
	scene.add(fill);
}
//#endregion
export { createGame };
