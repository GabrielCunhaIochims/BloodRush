import { createFileRoute } from "@tanstack/react-router";
import { BloodRush } from "@/game/BloodRush";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <BloodRush />;
}
