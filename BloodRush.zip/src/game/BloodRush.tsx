import { useEffect, useRef, useState } from "react";
import type { GameHud } from "./engine";

const INITIAL: GameHud = {
  hp: 100,
  maxHp: 100,
  kills: 0,
  wave: 1,
  score: 0,
  rank: "D",
  rankColor: "#a1a1aa",
  mult: 1,
  style: 0,
  best: 0,
  dashReady: true,
  phase: "menu",
  waveBanner: "",
  highScore: 0,
  looking: false,
  hitFlash: 0,
};

export function BloodRush() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<{ start: () => void; destroy: () => void } | null>(null);
  const [hud, setHud] = useState<GameHud>(INITIAL);
  const hudRef = useRef(hud);
  hudRef.current = hud;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let dead = false;
    let game: { start: () => void; destroy: () => void } | null = null;
    void import("./engine").then(({ createGame }) => {
      if (dead || !canvas) return;
      game = createGame(canvas, (next) => {
        const prev = hudRef.current;
        if (
          prev.phase !== next.phase ||
          Math.ceil(prev.hp) !== Math.ceil(next.hp) ||
          prev.kills !== next.kills ||
          prev.wave !== next.wave ||
          prev.score !== next.score ||
          prev.rank !== next.rank ||
          prev.dashReady !== next.dashReady ||
          prev.waveBanner !== next.waveBanner ||
          prev.looking !== next.looking ||
          Math.floor(prev.mult * 10) !== Math.floor(next.mult * 10) ||
          (prev.hitFlash > 0.2) !== (next.hitFlash > 0.2)
        ) {
          setHud(next);
        }
      });
      gameRef.current = game;
    });
    return () => {
      dead = true;
      game?.destroy();
      gameRef.current = null;
    };
  }, []);

  const hpPct = Math.max(0, Math.min(100, (hud.hp / hud.maxHp) * 100));

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <canvas
        ref={canvasRef}
        className="block h-full w-full touch-none"
        style={{ touchAction: "none" }}
      />

      {hud.phase === "playing" && (
        <div className="pointer-events-none absolute inset-0 p-4 sm:p-5">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0 rounded-lg border border-border bg-surface/80 px-3 py-2.5 backdrop-blur-sm">
              <div className="mb-1.5 h-2 w-44 overflow-hidden rounded-full bg-elevated sm:w-56">
                <div className="h-full bg-accent" style={{ width: `${hpPct}%` }} />
              </div>
              <dl className="grid grid-cols-2 gap-x-5 gap-y-0.5 font-mono text-xs tabular-nums text-muted">
                <div>
                  HP <span className="text-fg">{Math.max(0, Math.ceil(hud.hp))}</span>
                </div>
                <div>
                  WAVE <span className="text-fg">{hud.wave}</span>
                </div>
                <div>
                  KILLS <span className="text-fg">{hud.kills}</span>
                </div>
                <div>
                  SCORE <span className="text-fg">{hud.score}</span>
                </div>
              </dl>
            </div>
            <div className="text-right">
              <div
                className="font-display text-5xl leading-none tracking-wide sm:text-6xl"
                style={{ color: hud.rankColor }}
              >
                {hud.rank}
              </div>
              <div className="font-mono text-xs tabular-nums text-muted">
                x{hud.mult.toFixed(1)} · {Math.floor(hud.style)}
              </div>
              <div
                className={`mt-2 inline-block rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ${
                  hud.dashReady ? "border-fg/30 text-fg" : "border-border text-subtle"
                }`}
              >
                {hud.dashReady ? "DASH" : "…"}
              </div>
            </div>
          </div>

          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
            <div
              className={`absolute left-1/2 top-1/2 h-4 w-px -translate-x-1/2 -translate-y-1/2 ${hud.hitFlash > 0.15 ? "bg-accent" : "bg-fg/80"}`}
            />
            <div
              className={`absolute left-1/2 top-1/2 h-px w-4 -translate-x-1/2 -translate-y-1/2 ${hud.hitFlash > 0.15 ? "bg-accent" : "bg-fg/80"}`}
            />
          </div>

          {hud.waveBanner ? (
            <div className="absolute left-1/2 top-[38%] -translate-x-1/2 font-display text-6xl tracking-widest text-accent sm:text-7xl">
              {hud.waveBanner}
            </div>
          ) : null}

          {!hud.looking && (
            <p className="absolute bottom-16 left-1/2 -translate-x-1/2 font-mono text-[11px] uppercase tracking-widest text-muted">
              Clique para mirar
            </p>
          )}

          <p className="absolute bottom-4 left-4 hidden font-mono text-[10px] uppercase tracking-widest text-subtle sm:block">
            WASD mover · mouse mirar · clique atirar · shift dash
          </p>
        </div>
      )}

      <div className="pointer-events-none absolute inset-x-0 bottom-6 flex justify-between px-6 sm:hidden">
        <div className="h-24 w-24 rounded-full border border-border bg-surface/40" />
        <div className="h-16 w-16 rounded-full border border-border bg-surface/40" />
      </div>

      {hud.phase === "menu" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-bg/80 px-6 text-center">
          <p className="mb-3 font-mono text-[11px] uppercase tracking-[0.35em] text-accent">Arena 3D</p>
          <h1 className="font-display text-7xl leading-none tracking-wide text-fg sm:text-8xl">BLOOD RUSH</h1>
          <p className="mt-4 max-w-md font-sans text-sm leading-relaxed text-muted">
            Primeira pessoa. Shotgun. Dash atravessa demônios. Suba o rank de estilo.
          </p>
          <ul className="mt-6 space-y-1 font-mono text-[11px] uppercase tracking-wider text-subtle">
            <li>WASD — mover</li>
            <li>Mouse — olhar e atirar</li>
            <li>Shift — dash</li>
          </ul>
          {hud.highScore > 0 && (
            <p className="mt-4 font-mono text-xs tabular-nums text-muted">Recorde {hud.highScore}</p>
          )}
          <button
            type="button"
            className="mt-8 min-h-11 rounded-md bg-fg px-8 py-3 font-sans text-sm font-medium text-bg transition-transform duration-150 hover:opacity-90 active:scale-[0.98]"
            onClick={() => gameRef.current?.start()}
          >
            Começar
          </button>
        </div>
      )}

      {hud.phase === "dead" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-bg/88 px-6 text-center">
          <p className="font-mono text-[11px] uppercase tracking-[0.35em] text-accent">Caído</p>
          <h1 className="mt-2 font-display text-6xl tracking-wide text-fg">VOCÊ MORREU</h1>
          <p className="mt-4 font-mono text-lg tabular-nums text-fg">{hud.score}</p>
          <p className="mt-1 font-mono text-xs text-muted">
            {hud.kills} kills · wave {hud.wave} · rank {hud.rank}
          </p>
          <p className="mt-2 font-mono text-xs text-subtle">Recorde {hud.highScore}</p>
          <button
            type="button"
            className="mt-8 min-h-11 rounded-md bg-fg px-8 py-3 font-sans text-sm font-medium text-bg transition-transform duration-150 hover:opacity-90 active:scale-[0.98]"
            onClick={() => gameRef.current?.start()}
          >
            Tentar de novo
          </button>
        </div>
      )}
    </div>
  );
}
