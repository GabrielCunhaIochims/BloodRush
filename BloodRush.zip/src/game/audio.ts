export type AudioBus = {
  ctx: AudioContext;
  master: GainNode;
  sfx: GainNode;
};

export function createAudio(): AudioBus | null {
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AC) return null;
  const ctx = new AC({ latencyHint: "interactive" });
  const master = ctx.createGain();
  master.gain.value = 0.55;
  const sfx = ctx.createGain();
  sfx.gain.value = 1;
  sfx.connect(master);
  master.connect(ctx.destination);
  return { ctx, master, sfx };
}

export function unlockAudio(bus: AudioBus | null) {
  if (!bus) return;
  if (bus.ctx.state === "suspended") void bus.ctx.resume();
}

function beep(
  bus: AudioBus,
  freq: number,
  dur: number,
  type: OscillatorType,
  gain = 0.12,
  slide = 0,
) {
  const t = bus.ctx.currentTime;
  const o = bus.ctx.createOscillator();
  const g = bus.ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g);
  g.connect(bus.sfx);
  o.start(t);
  o.stop(t + dur + 0.02);
}

export const sfx = {
  shoot(bus: AudioBus | null) {
    if (!bus) return;
    beep(bus, 180 + Math.random() * 40, 0.08, "square", 0.07, -80);
  },
  dash(bus: AudioBus | null) {
    if (!bus) return;
    beep(bus, 420, 0.12, "sawtooth", 0.08, -280);
  },
  hit(bus: AudioBus | null) {
    if (!bus) return;
    beep(bus, 90 + Math.random() * 30, 0.09, "triangle", 0.1, -40);
  },
  kill(bus: AudioBus | null) {
    if (!bus) return;
    beep(bus, 140, 0.18, "sawtooth", 0.11, -90);
    beep(bus, 280, 0.12, "square", 0.05, 120);
  },
  hurt(bus: AudioBus | null) {
    if (!bus) return;
    beep(bus, 70, 0.22, "sawtooth", 0.14, -30);
  },
  wave(bus: AudioBus | null) {
    if (!bus) return;
    beep(bus, 220, 0.25, "triangle", 0.08, 180);
  },
  coin(bus: AudioBus | null) {
    if (!bus) return;
    beep(bus, 880, 0.12, "square", 0.07, 220);
  },
  bank(bus: AudioBus | null) {
    if (!bus) return;
    beep(bus, 1400, 0.16, "square", 0.1, -400);
    beep(bus, 420, 0.2, "sawtooth", 0.08, 200);
  },
};
