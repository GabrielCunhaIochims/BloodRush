export type WeaponId = "scatter" | "nailer" | "duelist" | "pierce";

export type DraftCard = {
  id: string;
  title: string;
  desc: string;
};

export type RunMods = {
  dmg: number;
  fireMul: number;
  pellets: number;
  lifesteal: number;
  coinChain: number;
  coinToss: number;
  pierce: number;
  dashCd: number;
  speed: number;
  maxHp: number;
};

export const WEAPON_META: Record<
  WeaponId,
  { name: string; hint: string; rate: number; hold: boolean; alt: boolean }
> = {
  scatter: { name: "SCATTER", hint: "espalha de perto", rate: 0.42, hold: true, alt: false },
  nailer: { name: "NAILER", hint: "automático", rate: 0.085, hold: true, alt: false },
  duelist: { name: "DUELIST", hint: "F / botão direito: moeda", rate: 0.36, hold: false, alt: true },
  pierce: { name: "PIERCE", hint: "atravessa a linha", rate: 0.82, hold: false, alt: false },
};

export function defaultMods(): RunMods {
  return {
    dmg: 1,
    fireMul: 1,
    pellets: 7,
    lifesteal: 6,
    coinChain: 1,
    coinToss: 1,
    pierce: 0,
    dashCd: 0.72,
    speed: 8.4,
    maxHp: 100,
  };
}

const ALL_CARDS: { card: DraftCard; once?: boolean; weapon?: WeaponId }[] = [
  { card: { id: "w_nailer", title: "NAILER", desc: "Metralhadora rápida. Segure o clique." }, once: true, weapon: "nailer" },
  { card: { id: "w_duelist", title: "DUELIST", desc: "Revólver. Jogue uma moeda e atire nela para ricochetear no alvo." }, once: true, weapon: "duelist" },
  { card: { id: "w_pierce", title: "PIERCE", desc: "Tiro pesado que atravessa demônios em linha." }, once: true, weapon: "pierce" },
  { card: { id: "dmg", title: "CARGA OCA", desc: "+25% de dano em todas as armas." } },
  { card: { id: "fire", title: "MÃOS RÁPIDAS", desc: "Cadência +20%." } },
  { card: { id: "hp", title: "SANGUE GROSSO", desc: "+30 HP máximo e cura total." } },
  { card: { id: "dash", title: "DEPOIS-IMAGEM", desc: "Dash recarrega 25% mais rápido." } },
  { card: { id: "pellets", title: "BOCA LARGA", desc: "Scatter ganha +3 projéteis." } },
  { card: { id: "chain", title: "BANCO DE OSSOS", desc: "Bankshot da moeda encadeia +1 alvo." } },
  { card: { id: "coins", title: "BOLSO FUNDO", desc: "Toss de moeda lança +1 discos." } },
  { card: { id: "leech", title: "SANGUESSUGA", desc: "+5 de cura por abate." } },
  { card: { id: "speed", title: "ESPORA", desc: "+14% de velocidade." } },
  { card: { id: "pierce", title: "FIO FRIO", desc: "Hitscan atravessa +1 inimigo." } },
];

export function rollDraft(owned: WeaponId[], taken: Set<string>): DraftCard[] {
  const pool = ALL_CARDS.filter((c) => {
    if (taken.has(c.card.id)) return false;
    if (c.weapon && owned.includes(c.weapon)) return false;
    return true;
  });
  const copy = [...pool];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  const picked = copy.slice(0, 3).map((c) => c.card);
  while (picked.length < 3) {
    picked.push({ id: `hp_${picked.length}`, title: "SANGUE GROSSO", desc: "+30 HP máximo e cura total." });
  }
  return picked;
}

export function applyCard(id: string, mods: RunMods, owned: WeaponId[]): WeaponId | null {
  if (id.startsWith("hp")) {
    mods.maxHp += 30;
    return null;
  }
  switch (id) {
    case "w_nailer":
      if (!owned.includes("nailer")) owned.push("nailer");
      return "nailer";
    case "w_duelist":
      if (!owned.includes("duelist")) owned.push("duelist");
      return "duelist";
    case "w_pierce":
      if (!owned.includes("pierce")) owned.push("pierce");
      return "pierce";
    case "dmg":
      mods.dmg *= 1.25;
      break;
    case "fire":
      mods.fireMul *= 0.8;
      break;
    case "hp":
      mods.maxHp += 30;
      break;
    case "dash":
      mods.dashCd *= 0.75;
      break;
    case "pellets":
      mods.pellets += 3;
      break;
    case "chain":
      mods.coinChain += 1;
      break;
    case "coins":
      mods.coinToss += 1;
      break;
    case "leech":
      mods.lifesteal += 5;
      break;
    case "speed":
      mods.speed *= 1.14;
      break;
    case "pierce":
      mods.pierce += 1;
      break;
  }
  return null;
}
